package com.example.sujeet.phonetracker;

public class User {

    private String email;
    private String username;
    private double lat;
    private double log;

    public User(String email, String username, double lat, double log) {
        this.email = email;
        this.username = username;
        this.lat = lat;
        this.log = log;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLog() {
        return log;
    }

    public void setLog(double log) {
        this.log = log;
    }
}
