package com.example.sujeet.phonetracker;


import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity  {

    // UI references.
    private static final String TAG = "Login";
    private EditText mEmailView;
    private EditText mPasswordView;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        // Set up the login form.
        mEmailView = (EditText) findViewById(R.id.email_input);
        mPasswordView = (EditText) findViewById(R.id.Password_input);

        Button mEmailSignInButton = (Button) findViewById(R.id.email_signin);
        mAuth = FirebaseAuth.getInstance();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if(user !=null){
                    //  updateUI(user);
                }
            }

        };
        mAuth.addAuthStateListener(mAuthListener);

        mEmailSignInButton.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        String email = mEmailView.getText().toString();
                        String password = mPasswordView.getText().toString();
                        if (!TextUtils.isEmpty(email) && !TextUtils.isEmpty(password)) {
                            mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (!task.isSuccessful()) {
                                        Toast.makeText(LoginActivity.this, "Authentication failed.",
                                                Toast.LENGTH_SHORT).show();
                                    } else {
                                        Intent intent=new Intent(LoginActivity.this,MapsActivity.class);
                                        startActivity(intent);
                                        // If sign in fails, display a message to the user.
                                      //  Log.w(TAG, "createUserWithEmail:failure", task.getException());

                                      //  updateUI(null);
                                    }

                                    // ...
                                }
                            });
                        } else {
                         Toast.makeText(LoginActivity.this,"Fill the parameters", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }

            // public void updateUI(FirebaseUser user){

            //    }
            public void onStart() {
                super.onStart();
                // Check if user is signed in (non-null) and update UI accordingly.
                FirebaseUser currentUser = mAuth.getCurrentUser();
                // updateUI(currentUser);
            }

        }





